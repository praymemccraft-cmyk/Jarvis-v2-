package com.jarvis.ultimate;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

/**
 * Lightweight animated "arc reactor" drawn with Canvas only (no bitmaps).
 * Redraws only while attached and visible, so it costs nothing in the background.
 */
public class ArcReactorView extends View {

    private static final int CYAN = 0xFF00E5FF;

    private final Paint arcPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tickPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private float density = 1f;
    private float rot = 0f;
    private float phase = 0f;
    private float level = 0f;
    private float targetLevel = 0f;
    private boolean active = false;
    private long lastNanos = 0L;
    private float glowRadius = 0f;

    public ArcReactorView(Context context) {
        super(context);
        init();
    }

    public ArcReactorView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ArcReactorView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        density = getResources().getDisplayMetrics().density;

        arcPaint.setStyle(Paint.Style.STROKE);
        arcPaint.setStrokeCap(Paint.Cap.ROUND);
        arcPaint.setColor(CYAN);

        tickPaint.setStyle(Paint.Style.STROKE);
        tickPaint.setStrokeWidth(1.5f * density);
        tickPaint.setColor(0x9900E5FF);

        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setStrokeWidth(1f * density);
        ringPaint.setColor(0x6600E5FF);

        glowPaint.setStyle(Paint.Style.FILL);
        dotPaint.setStyle(Paint.Style.FILL);
        dotPaint.setColor(0xFFE0FFFF);
    }

    /** Active = faster spin + stronger pulse (listening or speaking). */
    public void setActive(boolean active) {
        this.active = active;
    }

    /** Voice level 0..1 (from microphone RMS). */
    public void setLevel(float level) {
        if (level < 0f) level = 0f;
        if (level > 1f) level = 1f;
        this.targetLevel = level;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        float r = Math.min(w, h) / 2f;
        if (r <= 0f) return;
        glowRadius = r * 0.55f;
        glowPaint.setShader(new RadialGradient(
                w / 2f, h / 2f, glowRadius,
                new int[]{0xFFFFFFFF, 0xFF00E5FF, 0x0000E5FF},
                new float[]{0f, 0.35f, 1f},
                Shader.TileMode.CLAMP));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        float cx = w / 2f;
        float cy = h / 2f;
        float radius = Math.min(w, h) / 2f - 4f * density;
        if (radius <= 0f) return;

        long now = System.nanoTime();
        if (lastNanos == 0L) lastNanos = now;
        float dt = (now - lastNanos) / 1_000_000_000f;
        if (dt > 0.05f) dt = 0.05f;
        lastNanos = now;

        rot = (rot + dt * (active ? 200f : 55f)) % 360f;
        phase += dt * (active ? 7f : 2.2f);
        level += (targetLevel - level) * Math.min(1f, dt * 10f);

        float pulse = (float) (Math.sin(phase) * 0.5 + 0.5);

        // Core glow
        if (glowRadius > 0f) {
            glowPaint.setAlpha((int) (170 + 85 * pulse));
            float s = 0.9f + 0.12f * pulse + 0.25f * level;
            canvas.save();
            canvas.scale(s, s, cx, cy);
            canvas.drawCircle(cx, cy, glowRadius, glowPaint);
            canvas.restore();
        }

        // Outer ring + rotating ticks
        canvas.drawCircle(cx, cy, radius, ringPaint);
        canvas.save();
        canvas.rotate(-rot * 0.5f, cx, cy);
        for (int i = 0; i < 60; i++) {
            float len = (i % 5 == 0 ? 10f : 5f) * density;
            canvas.drawLine(cx, cy - radius, cx, cy - radius + len, tickPaint);
            canvas.rotate(6f, cx, cy);
        }
        canvas.restore();

        // Rotating arc rings
        drawArcs(canvas, cx, cy, radius * 0.84f, 4f * density, 3, 70f, rot, 255);
        drawArcs(canvas, cx, cy, radius * 0.68f, 3f * density, 4, 50f, -rot * 1.6f, 200);
        drawArcs(canvas, cx, cy, radius * 0.52f, 2f * density, 2, 120f, rot * 2.4f, 160);

        // Center dot
        canvas.drawCircle(cx, cy, radius * 0.11f * (1f + 0.2f * pulse), dotPaint);

        postInvalidateOnAnimation();
    }

    private void drawArcs(Canvas canvas, float cx, float cy, float r, float stroke,
                          int count, float sweep, float startRot, int alpha) {
        arcPaint.setStrokeWidth(stroke);
        arcPaint.setAlpha(alpha);
        rect.set(cx - r, cy - r, cx + r, cy + r);
        float step = 360f / count;
        for (int i = 0; i < count; i++) {
            canvas.drawArc(rect, startRot + i * step, sweep, false, arcPaint);
        }
    }
}
